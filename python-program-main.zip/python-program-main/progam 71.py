'''program to append to a file'''

with open('name.txt','a') as name:
    name.write("This line is appended in the file")
