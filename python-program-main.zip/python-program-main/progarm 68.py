'''program to randomly select a element from a list'''

import random
mylist=[2,3,6,5,7,8,4,'rajnish','tripathi']
print(random.choice(mylist))