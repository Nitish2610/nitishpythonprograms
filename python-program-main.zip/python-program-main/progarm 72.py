'''program to delete element from the dictionary'''

dic={1:34,4:43,3:234,6:456}
del dic[1]
print(dic)