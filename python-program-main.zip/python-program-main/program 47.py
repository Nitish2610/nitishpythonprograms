'''program to merge two dictionaries'''

dict1={'a': 3 ,'c':2,'t':12,'e':23}
dict2={'c':21,'d':32,'f':89}

# merge sort
dict1.update(dict2)
print(dict1)